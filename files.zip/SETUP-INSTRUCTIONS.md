# RetroChat — Full-Stack Real-Time Chat Application

A production-ready chat app with Node.js/Express/Socket.IO backend, React frontend, MongoDB storage, JWT auth, OpenAI integration, and Android WebView APK.

---

## Project Structure

```
chatapp/
├── backend/                  # Node.js + Express + Socket.IO
│   ├── config/db.js          # MongoDB connection
│   ├── middleware/
│   │   ├── auth.js           # JWT middleware + Socket auth
│   │   └── sanitize.js       # Input sanitization
│   ├── models/
│   │   ├── User.js           # User schema (nickname, 8-digit ID)
│   │   └── Message.js        # Message schema
│   ├── routes/
│   │   ├── auth.js           # Login / profile / settings
│   │   ├── chat.js           # Message history / online count
│   │   └── ai.js             # OpenAI integration
│   ├── server.js             # Main server + Socket.IO events
│   ├── .env.example          # Environment variable template
│   └── package.json
│
├── frontend/                 # React (mobile-first)
│   ├── public/index.html
│   ├── src/
│   │   ├── context/
│   │   │   └── AuthContext.js    # Global auth state
│   │   ├── pages/
│   │   │   ├── LoginPage.js      # Nickname entry
│   │   │   ├── ChatPage.js       # Real-time chat + AI toggle
│   │   │   ├── ProfilePage.js    # User profile + 8-digit ID
│   │   │   └── SettingsPage.js   # Preferences + logout
│   │   ├── utils/
│   │   │   ├── api.js            # Axios instance + session helpers
│   │   │   └── socket.js         # Socket.IO client
│   │   ├── App.js               # Main app + layout
│   │   ├── index.css            # Global retro dark blue styles
│   │   └── index.js
│   ├── .env.example
│   └── package.json
│
└── android/                  # Android WebView project
    ├── app/src/main/
    │   ├── java/com/retrochat/MainActivity.java
    │   ├── res/layout/activity_main.xml
    │   ├── res/values/strings.xml
    │   └── AndroidManifest.xml
    ├── build.gradle
    └── settings.gradle
```

---

## Quick Start (Local Development)

### Prerequisites
- Node.js 18+
- MongoDB (local or Atlas)
- npm or yarn

### 1. Backend Setup

```bash
cd backend
npm install

# Copy and configure environment variables
cp .env.example .env
```

Edit `.env`:
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/chatapp
JWT_SECRET=your_minimum_32_character_secret_key_here
OPENAI_API_KEY=sk-your-openai-key           # Optional - AI chat
CLIENT_URL=http://localhost:3000
```

```bash
# Start backend (development with auto-reload)
npm run dev

# Or production
npm start
```

Backend runs on: **http://localhost:5000**

### 2. Frontend Setup

```bash
cd frontend
npm install

cp .env.example .env
```

Edit `.env`:
```env
REACT_APP_API_URL=http://localhost:5000
REACT_APP_SOCKET_URL=http://localhost:5000
```

```bash
npm start
```

Frontend runs on: **http://localhost:3000**

---

## API Reference

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login or create user |
| GET | `/api/auth/me` | Get current user |
| PUT | `/api/auth/settings` | Update settings |
| POST | `/api/auth/logout` | Sign out |

**POST /api/auth/login**
```json
// Request
{ "nickname": "John", "userId": "12345678" }

// Response (new user)
{
  "success": true,
  "token": "eyJhbGci...",
  "user": {
    "id": "mongo_id",
    "nickname": "John",
    "userId": "47291038",    // Generated 8-digit permanent ID
    "joinDate": "2024-01-15T...",
    "settings": { "soundEnabled": true }
  }
}
```

### Chat

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/chat/history?limit=50` | Get message history |
| GET | `/api/chat/online` | Get online user count |

### AI

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/ai/message` | Send message to OpenAI |

**POST /api/ai/message**
```json
// Request
{
  "message": "Hello AI!",
  "conversationHistory": [
    { "content": "Hi", "isAi": false },
    { "content": "Hello! How can I help?", "isAi": true }
  ]
}
```

### Socket.IO Events

**Client → Server:**
| Event | Payload | Description |
|-------|---------|-------------|
| `sendMessage` | `{ content, room }` | Send a chat message |
| `typing` | `{ isTyping, room }` | Typing indicator |

**Server → Client:**
| Event | Payload | Description |
|-------|---------|-------------|
| `newMessage` | Message object | New message received |
| `systemMessage` | `{ content, timestamp }` | Join/leave notifications |
| `userTyping` | `{ userId, nickname, isTyping }` | Typing indicator |
| `onlineCount` | `{ count }` | Online users count |

---

## Deployment

### Backend → Render

1. Go to [render.com](https://render.com) → New Web Service
2. Connect your GitHub repository
3. Configure:
   - **Build Command:** `cd backend && npm install`
   - **Start Command:** `cd backend && node server.js`
   - **Environment:** Node
4. Add Environment Variables in Render dashboard:
   ```
   PORT=10000
   NODE_ENV=production
   MONGODB_URI=mongodb+srv://...
   JWT_SECRET=your_strong_secret_here
   OPENAI_API_KEY=sk-...
   CLIENT_URL=https://your-app.vercel.app
   RATE_LIMIT_WINDOW_MS=60000
   RATE_LIMIT_MAX_REQUESTS=60
   ```

### Backend → Railway

1. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
2. Set root directory to `backend`
3. Add same environment variables
4. Railway auto-detects Node.js and deploys

### Frontend → Vercel

1. Go to [vercel.com](https://vercel.com) → New Project
2. Import your repository
3. Set **Root Directory** to `frontend`
4. Add Environment Variables:
   ```
   REACT_APP_API_URL=https://your-backend.onrender.com
   REACT_APP_SOCKET_URL=https://your-backend.onrender.com
   ```
5. Deploy — Vercel auto-detects Create React App

### MongoDB Atlas (Recommended for Production)

1. Go to [cloud.mongodb.com](https://cloud.mongodb.com)
2. Create free cluster → Create database user
3. Network Access → Add IP: `0.0.0.0/0` (or your server IP)
4. Connect → Drivers → Copy connection string:
   ```
   mongodb+srv://username:password@cluster.mongodb.net/chatapp
   ```

---

## Android APK Build

### Prerequisites
- Android Studio (latest)
- JDK 17+
- Android SDK 34

### Setup Steps

**1. Open project in Android Studio:**
```
File → Open → Select android/ folder
```

**2. Update the server URL in MainActivity.java:**
```java
// Line 17 - change to your deployed frontend URL
private static final String APP_URL = "https://your-retrochat-app.vercel.app";
```

**3. Sync Gradle:**
```
File → Sync Project with Gradle Files
```

**4. Generate a Keystore (first time only):**
```bash
keytool -genkey -v -keystore retrochat.jks \
  -alias retrochat \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```
Move `retrochat.jks` to `android/keystore/`

**5. Configure signing in app/build.gradle:**
```gradle
signingConfigs {
    release {
        storeFile file("../keystore/retrochat.jks")
        storePassword "YOUR_KEYSTORE_PASSWORD"
        keyAlias "retrochat"
        keyPassword "YOUR_KEY_PASSWORD"
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        // ...
    }
}
```

**6. Build signed APK:**
```
Build → Generate Signed Bundle / APK → APK → Next
Select your keystore → Build (Release)
```

Output: `app/build/outputs/apk/release/app-release.apk`

**7. Install on device:**
```bash
adb install app/build/outputs/apk/release/app-release.apk
```

---

## Security Features

| Feature | Implementation |
|---------|---------------|
| JWT Authentication | 90-day tokens, verified on every request |
| Input Sanitization | HTML entity escaping on all inputs |
| Rate Limiting | 60 req/min global, 15 msg/30s per socket, 10 AI req/min |
| CORS | Whitelist-based origin validation |
| MongoDB Injection | Mongoose schema validation + sanitization |
| WebView Security | cleartext disabled, external URLs blocked |
| Environment Variables | All secrets via .env, never hardcoded |

---

## Key Features Summary

✅ **8-digit permanent user ID** — generated on first login, stored forever
✅ **Real-time messaging** via Socket.IO with acknowledgements
✅ **Typing indicators** — "User is typing..." shown to all room members  
✅ **Chat history** — persisted in MongoDB, loaded on connect
✅ **AI Chat mode** — toggle sends messages to OpenAI (GPT-3.5-turbo)
✅ **Online count** — live counter of connected users
✅ **JWT sessions** — stored in localStorage, auto-restored on reload
✅ **Rate limiting** — prevents spam (socket + HTTP layers)
✅ **Mobile-first design** — retro dark blue theme, 600px max-width
✅ **Android WebView APK** — loads your deployed React app natively

---

## Troubleshooting

**Socket connection fails:**
- Ensure backend CORS includes your frontend URL
- Check `REACT_APP_SOCKET_URL` points to backend (not frontend)
- Render free tier sleeps — first connection may take 30s

**Messages not saving:**
- Verify MongoDB URI is correct and IP whitelist includes `0.0.0.0/0`
- Check MongoDB Atlas → Collections → chatapp.messages

**AI not responding:**
- Verify `OPENAI_API_KEY` is set in backend environment variables
- Check OpenAI billing/quota at platform.openai.com
- App works without AI key — shows "service not configured" message

**Android WebView blank screen:**
- Ensure `APP_URL` in MainActivity.java uses `https://` (not `http://`)
- Check device has internet connection
- Enable `android:usesCleartextTraffic="true"` in AndroidManifest only for HTTP testing

**JWT errors after deployment:**
- `JWT_SECRET` must be identical across all backend instances
- Minimum 32 characters recommended for security
